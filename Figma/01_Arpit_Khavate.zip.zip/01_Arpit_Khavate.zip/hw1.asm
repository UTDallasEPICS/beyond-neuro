.data
    promptX:   .asciiz "Enter integer X: "
    promptY:   .asciiz "Enter integer Y: "
    resultMsg: .asciiz "The difference between X and Y (X - Y) is "
    X: .word 0
    Y: .word 0
    D: .word 0

.text
.globl main
main:
    # Prompt user for X
    li $v0, 4
    la $a0, promptX
    syscall

    # Read integer X and store in memory
    li $v0, 5
    syscall
    sw $v0, X

    # Prompt user for Y
    li $v0, 4
    la $a0, promptY
    syscall

    # Read integer Y and store in memory
    li $v0, 5
    syscall
    sw $v0, Y

    # Load X and Y from memory, calculate difference
    lw $t0, X
    lw $t1, Y
    sub $t2, $t0, $t1

    # Store result in memory labeled D
    sw $t2, D

    # Print the result string
    li $v0, 4
    la $a0, resultMsg
    syscall

    # Print the integer result (D)
    li $v0, 1
    lw $a0, D
    syscall

    # Exit program cleanly
    li $v0, 10
    syscall